# 完全自動背景更新（不跳安裝精靈）的做法（Python 桌面 App 可行版本）

## 你要的效果
- 使用者「不用裝 Python」
- 初次安裝後：之後更新完全在背景下載
- 更新套用：**不跳 MSI/安裝精靈**，直接換掉 EXE 然後自動重開

> 這種方式最像「portable app 自更新」：適合放在使用者資料夾（%LOCALAPPDATA%），不需要管理員權限。

---

## 原理（兩個 EXE）
1) `PDF2PPT.exe` 主程式（PyInstaller onefile，內建 runtime）
2) `PDF2PPT_updater.exe` 更新助手
   - 等主程式退出
   - 把下載好的新版 EXE 覆蓋舊版
   - 重啟主程式

---

## 你要改的唯一重點
`app/main.py` 的 `MANIFEST_URL` 改成你自己的更新站網址

---

## 更新站（manifest.json）
你要提供一個 JSON：

{
  "version": "1.0.1",
  "exe_url": "https://.../PDF2PPT.exe",
  "sha256": "<exe 的 sha256>",
  "notes": "..."
}

主程式會：
- 背景抓 manifest
- 比版本（remote > local）
- 下載 exe
- 驗 sha256
- 立刻啟動 updater swap → 自動重開（沒有任何安裝精靈）

---

## 本機打包（Windows）
PowerShell：

scripts\build_exe_pair.ps1

會產出：
- dist\PDF2PPT.exe
- dist\PDF2PPT_updater.exe  （務必與主程式放同一資料夾）

---

## 初次安裝（兩條路）
A) 最省事：你直接給使用者一個 zip（解壓縮後雙擊 PDF2PPT.exe）
B) 更像「安裝」：用 NSIS 打一個 installer（可 silent）
   - 先裝 NSIS
   - 用 installer/PDF2PPT.nsi 產出 PDF2PPT_Setup.exe
   - silent 安裝：PDF2PPT_Setup.exe /S
   - 安裝到 $LOCALAPPDATA，不會跳 UAC

---

## 注意（很重要）
- **如果你堅持安裝到 Program Files（系統目錄）**，覆蓋 EXE 通常需要管理員權限 → 會跳 UAC
- 所以「完全無感」最佳做法：安裝到 **使用者資料夾**（per-user）


## ✅ 不用改程式碼：直接設定更新來源
你現在 **不需要改 `MANIFEST_URL`** 了。更新來源三選一：

1) 環境變數
   - `PDF2PPT_MANIFEST_URL`

2) config.json（推薦）
   - 放在 `PDF2PPT.exe` 同資料夾
   - `{"manifest_url":"https://.../manifest.json"}`
   - 也可用 `file:///C:/.../manifest.json`

3) EXE 同資料夾放 manifest.json
   - 直接放 `manifest.json` 在 EXE 旁邊就會自動抓（file://）

> 若 `manifest_url` 留空，背景更新會自動停用（不會報錯）。

## 產生 manifest.json（不手動算 sha256）
使用：`scripts\publish_update.ps1 -UpdateDir <資料夾> -Version 1.0.1`