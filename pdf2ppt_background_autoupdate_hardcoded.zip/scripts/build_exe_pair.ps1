$ErrorActionPreference = "Stop"
python -m pip install --upgrade pip
pip install -r requirements.txt

# Build main EXE
pyinstaller --noconsole --onefile --name PDF2PPT --clean app\main.py

# Build updater helper EXE (console off)
pyinstaller --noconsole --onefile --name PDF2PPT_updater --clean app\updater_helper.py

Write-Host "Built:"
Write-Host " - dist\PDF2PPT.exe"
Write-Host " - dist\PDF2PPT_updater.exe (must live next to PDF2PPT.exe)"
