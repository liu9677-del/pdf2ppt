$ErrorActionPreference = "Stop"

param(
  [Parameter(Mandatory=$true)][string]$UpdateDir,
  [Parameter(Mandatory=$true)][string]$Version,
  [string]$ExeName = "PDF2PPT.exe",
  [string]$BaseUrl = ""  # optional: https://example.com/pdf2ppt
)

$exePath = Join-Path $UpdateDir $ExeName
if (!(Test-Path $exePath)) { throw "EXE not found: $exePath" }

$sha256 = (Get-FileHash -Algorithm SHA256 $exePath).Hash.ToLower()

if ($BaseUrl -ne "") {
  $exeUrl = "$BaseUrl/$ExeName"
} else {
  $exeUrl = (Get-Item $exePath).FullName
  $exeUrl = (New-Object System.Uri($exeUrl)).AbsoluteUri
}

$manifest = @{
  version = $Version
  exe_url = $exeUrl
  sha256  = $sha256
  notes   = "Auto-published update"
}
$manifestPath = Join-Path $UpdateDir "manifest.json"
$manifest | ConvertTo-Json -Depth 5 | Out-File -Encoding utf8 $manifestPath

Write-Host "manifest.json written to: $manifestPath"
Write-Host "exe_url: $exeUrl"
Write-Host "sha256: $sha256"
