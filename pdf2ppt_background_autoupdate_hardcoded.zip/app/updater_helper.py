import os, sys, time, shutil, subprocess

def wait_for_unlock(path: str, timeout_sec: int = 60):
    t0 = time.time()
    while True:
        try:
            # attempt open for append to test lock
            with open(path, "ab"):
                return
        except PermissionError:
            if time.time() - t0 > timeout_sec:
                raise
            time.sleep(0.5)

def main():
    # args: <current_exe> <staged_exe> <relaunch:0|1>
    if len(sys.argv) < 3:
        print("usage: updater.exe <current_exe> <staged_exe> [relaunch]")
        return 2
    current_exe = sys.argv[1]
    staged_exe = sys.argv[2]
    relaunch = (sys.argv[3] if len(sys.argv) > 3 else "1") != "0"

    # Wait current process exit / file unlock
    wait_for_unlock(current_exe, timeout_sec=120)

    # Backup old
    bak = current_exe + ".bak"
    try:
        if os.path.exists(bak):
            os.remove(bak)
    except Exception:
        pass
    try:
        shutil.move(current_exe, bak)
    except Exception:
        # If move fails, attempt overwrite later
        pass

    # Replace
    shutil.copy2(staged_exe, current_exe)

    # Relaunch
    if relaunch:
        subprocess.Popen([current_exe], close_fds=True)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
