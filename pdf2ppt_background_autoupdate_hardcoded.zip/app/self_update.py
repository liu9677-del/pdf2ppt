from __future__ import annotations
import hashlib, json, os, tempfile, time
from dataclasses import dataclass
from urllib.request import urlopen, Request

@dataclass
class Manifest:
    version: str
    exe_url: str
    sha256: str
    notes: str | None = None

def version_tuple(v: str):
    parts=[]
    for x in v.split("."):
        try: parts.append(int(x))
        except: parts.append(0)
    while len(parts)<3: parts.append(0)
    return tuple(parts[:3])

def is_newer(remote: str, local: str) -> bool:
    return version_tuple(remote) > version_tuple(local)

def fetch_manifest(url: str, timeout: int = 10) -> Manifest:
    req = Request(url, headers={"User-Agent":"PDF2PPT-SelfUpdate"})
    with urlopen(req, timeout=timeout) as resp:
        data = resp.read().decode("utf-8", errors="replace")
    obj = json.loads(data)
    return Manifest(
        version=str(obj.get("version","")).strip(),
        exe_url=str(obj.get("exe_url","")).strip(),
        sha256=str(obj.get("sha256","")).strip().lower(),
        notes=obj.get("notes"),
    )

def _sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def download(url: str, dst: str):
    req = Request(url, headers={"User-Agent":"PDF2PPT-SelfUpdate"})
    with urlopen(req, timeout=60) as resp, open(dst, "wb") as f:
        while True:
            chunk = resp.read(1024*512)
            if not chunk: break
            f.write(chunk)

def stage_new_exe(manifest_url: str, local_version: str) -> tuple[str, Manifest] | tuple[None, Manifest | None]:
    """
    Returns (staged_exe_path, manifest) if update available and downloaded+verified, else (None, manifest or None).
    """
    try:
        m = fetch_manifest(manifest_url)
    except Exception:
        return (None, None)
    if not m.version or not m.exe_url or not m.sha256:
        return (None, m)
    if not is_newer(m.version, local_version):
        return (None, m)

    td = tempfile.mkdtemp(prefix="pdf2ppt_stage_")
    staged = os.path.join(td, "PDF2PPT.new.exe")
    download(m.exe_url, staged)
    if _sha256_file(staged) != m.sha256:
        raise RuntimeError("Downloaded file SHA256 mismatch")
    return (staged, m)
