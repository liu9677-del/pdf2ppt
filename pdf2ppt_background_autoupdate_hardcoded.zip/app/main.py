import os, sys, threading, time, tempfile, subprocess
from pathlib import Path

import customtkinter as ctk
from tkinter import filedialog, messagebox

import fitz
from pptx import Presentation
from pptx.util import Inches
from PIL import Image

from version import APP_NAME, APP_VERSION
from self_update import stage_new_exe

# === CHANGE THIS ===

# === Hardcoded update channel (no config / env needed) ===
MANIFEST_URL = "https://your-domain.com/pdf2ppt/manifest.json"
DEFAULT_DPI = 300
WIDE_W_IN = 13.333
WIDE_H_IN = 7.5

def set_wide(prs):
    prs.slide_width = Inches(WIDE_W_IN)
    prs.slide_height = Inches(WIDE_H_IN)

def add_image_slide(prs, img_path: Path):
    blank = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank)
    slide_w = prs.slide_width
    slide_h = prs.slide_height
    with Image.open(img_path) as im:
        img_w_px, img_h_px = im.size
    img_ratio = img_w_px / img_h_px
    slide_ratio = slide_w / slide_h
    if img_ratio > slide_ratio:
        w = slide_w
        h = int(w / img_ratio)
    else:
        h = slide_h
        w = int(h * img_ratio)
    left = int((slide_w - w) / 2)
    top = int((slide_h - h) / 2)
    slide.shapes.add_picture(str(img_path), left, top, width=w, height=h)

def render_pdf(pdf_path: Path, dpi: int, tmp_dir: Path, progress_cb=None):
    doc = fitz.open(pdf_path)
    zoom = dpi / 72.0
    mat = fitz.Matrix(zoom, zoom)
    img_paths = []
    for i in range(doc.page_count):
        page = doc.load_page(i)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        out = tmp_dir / f"page_{i+1:04d}.png"
        pix.save(out)
        img_paths.append(out)
        if progress_cb:
            progress_cb(i + 1, doc.page_count)
    doc.close()
    return img_paths

def safe_stem(p: Path) -> str:
    s = p.stem.strip()
    return "".join(ch if ch not in r'\/:*?"<>|' else "_" for ch in s) or "output"

def unique_out_path(out_dir: Path, base_name: str) -> Path:
    out = out_dir / f"{base_name}.pptx"
    if not out.exists():
        return out
    k = 2
    while True:
        out2 = out_dir / f"{base_name}_{k}.pptx"
        if not out2.exists():
            return out2
        k += 1

def current_exe_path() -> str:
    # When packaged by PyInstaller, sys.executable is the exe path
    return sys.executable

def launch_silent_swap(staged_exe: str):
    """
    Silently apply update by swapping current exe and relaunching.
    Requires updater helper exe next to main exe.
    """
    exe_dir = os.path.dirname(current_exe_path())
    updater = os.path.join(exe_dir, "PDF2PPT_updater.exe")
    if not os.path.exists(updater):
        raise RuntimeError("Updater helper not found (PDF2PPT_updater.exe)")
    # Spawn updater then exit immediately
    subprocess.Popen([updater, current_exe_path(), staged_exe, "1"], close_fds=True)

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")

        self.title(f"{APP_NAME}  PDF → PPTX")
        self.geometry("820x520")
        self.minsize(760, 500)

        self.pdf_paths = []
        self.out_dir = None
        self.is_running = False

        self._build_ui()

        # Background auto-update: check once at startup + every 6 hours
        threading.Thread(target=self._auto_update_loop, daemon=True).start()

    def _build_ui(self):
        header = ctk.CTkFrame(self, corner_radius=18)
        header.pack(fill="x", padx=18, pady=(18, 10))
        ctk.CTkLabel(header, text=f"{APP_NAME}  PDF → PPTX（每頁轉圖片）", font=ctk.CTkFont(size=20, weight="bold")).pack(anchor="w", padx=18, pady=(14, 2))
        self.status = ctk.CTkLabel(header, text=f"v{APP_VERSION}｜背景自動更新：開啟", text_color="#666666")
        self.status.pack(anchor="w", padx=18, pady=(0, 14))

        body = ctk.CTkFrame(self, corner_radius=18)
        body.pack(fill="both", expand=True, padx=18, pady=10)

        row1 = ctk.CTkFrame(body, fg_color="transparent")
        row1.pack(fill="x", padx=18, pady=(18, 8))
        ctk.CTkButton(row1, text="選擇 PDF（可多選）", command=self.pick_pdfs, height=38, corner_radius=12).pack(side="left")
        ctk.CTkButton(row1, text="選擇輸出資料夾", command=self.pick_out_dir, height=38, corner_radius=12).pack(side="left", padx=(10, 0))
        ctk.CTkButton(row1, text="開始轉換", command=self.start, height=38, corner_radius=12).pack(side="right")

        row2 = ctk.CTkFrame(body, fg_color="transparent")
        row2.pack(fill="x", padx=18, pady=8)
        ctk.CTkLabel(row2, text="DPI", font=ctk.CTkFont(size=13, weight="bold")).pack(side="left")
        self.dpi_var = ctk.StringVar(value="300")
        ctk.CTkEntry(row2, width=90, textvariable=self.dpi_var, corner_radius=10).pack(side="left", padx=(8, 18))
        ctk.CTkLabel(row2, text="16:9（固定）", text_color="#333333").pack(side="left")

        self.list_text = ctk.CTkTextbox(body, wrap="none")
        self.list_text.pack(fill="both", expand=True, padx=18, pady=(10, 12))
        self._set_list(["尚未選擇檔案。"])

        self.pb = ctk.CTkProgressBar(body)
        self.pb.set(0)
        self.pb.pack(fill="x", padx=18, pady=(0, 18))

    def _set_list(self, lines):
        self.list_text.configure(state="normal")
        self.list_text.delete("1.0", "end")
        self.list_text.insert("end", "\n".join(lines) + "\n")
        self.list_text.configure(state="disabled")

    def pick_pdfs(self):
        files = filedialog.askopenfilenames(title="選擇 PDF（可多選）", filetypes=[("PDF files", "*.pdf")])
        if not files:
            return
        self.pdf_paths = [Path(f) for f in files]
        self._set_list(["已選擇 PDF："] + [f"• {p.name}" for p in self.pdf_paths])

    def pick_out_dir(self):
        d = filedialog.askdirectory(title="選擇輸出資料夾")
        if not d:
            return
        self.out_dir = Path(d)
        self._toast(f"輸出：{self.out_dir}")

    def _toast(self, msg):
        self.after(0, lambda: self.status.configure(text=msg))

    def start(self):
        if self.is_running:
            return
        if not self.pdf_paths:
            messagebox.showwarning("缺少 PDF", "請先選擇至少一個 PDF。")
            return
        if not self.out_dir:
            messagebox.showwarning("缺少輸出資料夾", "請先選擇輸出資料夾。")
            return
        try:
            dpi = int(self.dpi_var.get().strip())
            if dpi < 72 or dpi > 600:
                raise ValueError
        except Exception:
            messagebox.showwarning("DPI 不正確", "請輸入 72～600 的整數 DPI（建議 300）。")
            return

        self.is_running = True
        threading.Thread(target=self._run_job, args=(dpi,), daemon=True).start()

    def _run_job(self, dpi: int):
        total_files = len(self.pdf_paths)
        try:
            for fi, pdf_path in enumerate(self.pdf_paths, start=1):
                with tempfile.TemporaryDirectory(prefix="pdf2ppt_") as td:
                    tmp_dir = Path(td)

                    def page_cb(done, total):
                        ratio = ((fi - 1) + done / max(total, 1)) / total_files
                        self.after(0, lambda r=ratio: self.pb.set(r))
                        self._toast(f"[{fi}/{total_files}] {pdf_path.name} {int(done/max(total,1)*100)}%")

                    page_cb(0, 1)
                    imgs = render_pdf(pdf_path, dpi, tmp_dir, progress_cb=page_cb)

                    prs = Presentation()
                    set_wide(prs)
                    for img in imgs:
                        add_image_slide(prs, img)

                    out_path = unique_out_path(self.out_dir, safe_stem(pdf_path))
                    prs.save(out_path)
                    self._toast(f"完成：{out_path.name}")

            self._toast("全部完成 ✅")
        except Exception as e:
            self._toast(f"失敗：{e}")
            messagebox.showerror("錯誤", str(e))
        finally:
            self.is_running = False
            self.after(0, lambda: self.pb.set(0))

    def _auto_update_loop(self):
        # initial delay for UI to show
        time.sleep(2)
        while True:
            try:
                staged, m = stage_new_exe(MANIFEST_URL, APP_VERSION)
                if staged and m:
                    # Silent apply: no installer wizard, just swap+relaunch
                    self._toast(f"更新中 → {m.version}（自動套用）")
                    launch_silent_swap(staged)
                    # Exit current app so updater can replace
                    os._exit(0)
                elif m and m.version:
                    self._toast(f"v{APP_VERSION}｜已是最新")
            except Exception as e:
                # keep quiet, but you can log if needed
                pass
            # check every 6 hours
            time.sleep(6 * 60 * 60)

if __name__ == "__main__":
    App().mainloop()
